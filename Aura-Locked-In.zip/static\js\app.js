const $ = (selector, root = document) => root.querySelector(selector);
const $$ = (selector, root = document) => [...root.querySelectorAll(selector)];

function showXp(message) {
  const pop = $("#xp-pop");
  if (!pop) return;
  pop.textContent = message;
  pop.classList.remove("show");
  void pop.offsetWidth;
  pop.classList.add("show");
}

function pulse(element) {
  if (!element) return;
  element.classList.remove("pulse-update");
  void element.offsetWidth;
  element.classList.add("pulse-update");
}

function setLiveValue(key, value, suffix = "") {
  $$(`[data-live="${key}"]`).forEach((element) => {
    const next = `${value}${suffix}`;
    if (element.textContent !== next) {
      element.textContent = next;
      pulse(element);
    }
  });
}

async function refreshLiveMetrics() {
  try {
    const response = await fetch("/api/metrics");
    const data = await response.json();
    setLiveValue("xp", data.xp, " XP");
    setLiveValue("level", data.level);
    setLiveValue("streak", data.streak);
    setLiveValue("habitCompletion", data.habitCompletion, "%");
    setLiveValue("completedHabits", data.completedHabits);
    setLiveValue("totalHabits", data.totalHabits);
    setLiveValue("todayXp", data.todayXp);
    setLiveValue("focusMinutes", data.focusMinutes);
    $$("[data-live-ring='habitCompletion']").forEach((ring) => {
      ring.style.setProperty("--value", data.habitCompletion);
    });
    if ($(".aura-chart")) await drawCharts();
  } catch {
    // The UI still reflects the clicked control even if the live refresh fails.
  }
}

$$("[data-xp]").forEach((button) => {
  button.addEventListener("click", () => showXp(button.dataset.xp));
});

$$("[data-habit-id]").forEach((checkbox) => {
  checkbox.addEventListener("change", async () => {
    const id = checkbox.dataset.habitId;
    try {
      const response = await fetch(`/api/habits/${id}/toggle`, { method: "POST" });
      const data = await response.json();
      const label = checkbox.closest(".done-today");
      if (label) {
        label.classList.toggle("is-done", Boolean(data.completed));
        const text = label.querySelector("span");
        if (text) text.textContent = data.completed ? "Done Today" : "Mark Done Today";
      }
      if (data.completed) showXp(`+${data.xp} XP habit complete`);
      await refreshLiveMetrics();
    } catch {
      showXp("Offline demo toggle");
    }
  });
});

$$("[data-topic-id]").forEach((checkbox) => {
  checkbox.addEventListener("change", async () => {
    const id = checkbox.dataset.topicId;
    try {
      const response = await fetch(`/api/skills/topics/${id}/toggle`, { method: "POST" });
      const data = await response.json();
      if (data.completed) showXp(`+${data.xp} XP topic complete`);
      await refreshLiveMetrics();
    } catch {
      showXp("Checklist saved locally after reload");
    }
  });
});

const search = $("#job-search");
if (search) {
  search.addEventListener("input", () => {
    const value = search.value.toLowerCase();
    $$("#jobs-table tbody tr").forEach((row) => {
      row.style.display = row.innerText.toLowerCase().includes(value) ? "" : "none";
    });
  });
}

$$(".filter-chip").forEach((chip) => {
  chip.addEventListener("click", () => {
    $$(".filter-chip").forEach((item) => item.classList.remove("active"));
    chip.classList.add("active");
    const status = chip.dataset.status;
    $$("#jobs-table tbody tr").forEach((row) => {
      row.style.display = status === "All" || row.dataset.status === status ? "" : "none";
    });
  });
});

$$(".table-select").forEach((select) => {
  select.addEventListener("change", async () => {
    const id = select.dataset.jobId;
    const field = select.dataset.field;
    const value = select.value;
    if (field === "status") {
      select.closest("tr").dataset.status = value;
      select.className = `table-select status-select ${value.toLowerCase().replaceAll(" ", "-")}`;
    }
    await fetch(`/api/jobs/${id}/update`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ field, value }),
    });
    showXp("Job tracker updated");
    await refreshLiveMetrics();
  });
});

const themeSelect = $("#theme-select");
if (themeSelect) {
  themeSelect.addEventListener("change", () => {
    document.body.className = document.body.className
      .split(" ")
      .filter((className) => !className.startsWith("theme-"))
      .join(" ");
    document.body.classList.add(`theme-${themeSelect.value}`);
    showXp(`${themeSelect.options[themeSelect.selectedIndex].text} preview`);
  });
}

let timerSeconds = 25 * 60;
let timerInitial = timerSeconds;
let timerMode = "25/5";
let timerInterval = null;

function renderTimer() {
  const display = $("#timer-display");
  if (!display) return;
  const minutes = Math.floor(timerSeconds / 60).toString().padStart(2, "0");
  const seconds = (timerSeconds % 60).toString().padStart(2, "0");
  display.textContent = `${minutes}:${seconds}`;
}

function stopTimer() {
  clearInterval(timerInterval);
  timerInterval = null;
}

$$(".mode-tabs button").forEach((button) => {
  button.addEventListener("click", () => {
    stopTimer();
    $$(".mode-tabs button").forEach((item) => item.classList.remove("active"));
    button.classList.add("active");
    timerInitial = Number(button.dataset.mode) * 60;
    timerSeconds = timerInitial;
    timerMode = `${button.dataset.mode}/${button.dataset.break}`;
    renderTimer();
  });
});

const startButton = $("#timer-start");
if (startButton) {
  startButton.addEventListener("click", () => {
    if (timerInterval) {
      stopTimer();
      startButton.textContent = "Start";
      return;
    }
    startButton.textContent = "Pause";
    timerInterval = setInterval(async () => {
      timerSeconds -= 1;
      renderTimer();
      if (timerSeconds <= 0) {
        stopTimer();
        startButton.textContent = "Start";
        const minutes = Math.round(timerInitial / 60);
        await fetch("/api/pomodoro/complete", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ minutes, mode: timerMode }),
        });
        showXp(`+${minutes * 2} XP focus session`);
        await refreshLiveMetrics();
        timerSeconds = timerInitial;
        renderTimer();
      }
    }, 1000);
  });
}

const resetButton = $("#timer-reset");
if (resetButton) {
  resetButton.addEventListener("click", () => {
    stopTimer();
    timerSeconds = timerInitial;
    if (startButton) startButton.textContent = "Start";
    renderTimer();
  });
}
renderTimer();

let audioContext = null;
let soundNodes = [];
let soundMode = "off";

function getAudioContext() {
  if (!audioContext) {
    audioContext = new (window.AudioContext || window.webkitAudioContext)();
  }
  return audioContext;
}

function stopSound() {
  soundNodes.forEach((node) => {
    try {
      if (node.stop) node.stop();
      if (node.disconnect) node.disconnect();
    } catch {
      // Some nodes may already be stopped after a quick sound-mode switch.
    }
  });
  soundNodes = [];
}

function makeNoiseBuffer(context) {
  const buffer = context.createBuffer(1, context.sampleRate * 2, context.sampleRate);
  const data = buffer.getChannelData(0);
  for (let i = 0; i < data.length; i += 1) {
    data[i] = Math.random() * 2 - 1;
  }
  return buffer;
}

function startSound(mode = soundMode) {
  stopSound();
  soundMode = mode;
  if (mode === "off") return;

  const context = getAudioContext();
  const volume = Number($("#sound-volume")?.value || 35) / 100;
  const gain = context.createGain();
  gain.gain.value = volume * 0.18;
  gain.connect(context.destination);
  soundNodes.push(gain);

  if (mode === "fire") {
    [90, 130, 175].forEach((frequency, index) => {
      const oscillator = context.createOscillator();
      oscillator.type = index === 0 ? "sawtooth" : "triangle";
      oscillator.frequency.value = frequency;
      oscillator.detune.value = Math.random() * 8;
      oscillator.connect(gain);
      oscillator.start();
      soundNodes.push(oscillator);
    });
  }

  if (mode === "rain" || mode === "noise" || mode === "fire") {
    const source = context.createBufferSource();
    const filter = context.createBiquadFilter();
    source.buffer = makeNoiseBuffer(context);
    source.loop = true;
    filter.type = mode === "rain" ? "bandpass" : "lowpass";
    filter.frequency.value = mode === "rain" ? 850 : mode === "fire" ? 420 : 1200;
    filter.Q.value = mode === "rain" ? 0.8 : mode === "fire" ? 1.2 : 0.2;
    source.connect(filter);
    filter.connect(gain);
    source.start();
    soundNodes.push(source, filter);
  }
}

$$(".sound-chip").forEach((chip) => {
  chip.addEventListener("click", async () => {
    $$(".sound-chip").forEach((item) => item.classList.remove("active"));
    chip.classList.add("active");
    if (audioContext?.state === "suspended") await audioContext.resume();
    startSound(chip.dataset.sound);
    showXp(chip.dataset.sound === "off" ? "Pomodoro sound off" : `${chip.textContent} on`);
  });
});

$("#sound-volume")?.addEventListener("input", () => {
  if (soundMode !== "off") startSound(soundMode);
});

async function getAnalytics() {
  try {
    const response = await fetch("/api/analytics");
    return await response.json();
  } catch {
    return {
      weeklyActivity: [42, 58, 47, 73, 66, 84, 91],
      weekLabels: ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"],
      studyHours: [1.5, 2.2, 1.8, 3.4, 2.5, 4.1, 3.8],
      habitLabels: ["Sleep", "Water", "Study", "Coding"],
      habitValues: [9, 11, 12, 5],
      skillLabels: ["Python", "SQL", "HTML/CSS", "Git"],
      skillValues: [67, 52, 76, 71],
      colors: ["#f472b6", "#a78bfa", "#fb7185", "#c084fc"],
    };
  }
}

function setupCanvas(canvas) {
  const dpr = window.devicePixelRatio || 1;
  const rect = canvas.getBoundingClientRect();
  canvas.width = rect.width * dpr;
  canvas.height = rect.height * dpr;
  const ctx = canvas.getContext("2d");
  ctx.scale(dpr, dpr);
  return { ctx, width: rect.width, height: rect.height };
}

function drawLine(canvas, values, labels = ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"]) {
  const { ctx, width, height } = setupCanvas(canvas);
  const pad = 34;
  const max = Math.max(...values, 1) + 2;
  ctx.clearRect(0, 0, width, height);
  ctx.strokeStyle = "rgba(255,255,255,0.08)";
  ctx.lineWidth = 1;
  for (let i = 0; i < 4; i += 1) {
    const y = pad + ((height - pad * 2) / 3) * i;
    ctx.beginPath();
    ctx.moveTo(pad, y);
    ctx.lineTo(width - pad, y);
    ctx.stroke();
  }
  const points = values.map((value, index) => ({
    x: pad + ((width - pad * 2) / (values.length - 1)) * index,
    y: height - pad - (value / max) * (height - pad * 2),
  }));
  const gradient = ctx.createLinearGradient(0, 0, width, 0);
  gradient.addColorStop(0, "#ff4fd8");
  gradient.addColorStop(0.55, "#8b5cf6");
  gradient.addColorStop(1, "#38bdf8");
  ctx.strokeStyle = gradient;
  ctx.lineWidth = 4;
  ctx.beginPath();
  points.forEach((point, index) => index ? ctx.lineTo(point.x, point.y) : ctx.moveTo(point.x, point.y));
  ctx.stroke();
  points.forEach((point) => {
    ctx.fillStyle = "#fbf7ff";
    ctx.beginPath();
    ctx.arc(point.x, point.y, 5, 0, Math.PI * 2);
    ctx.fill();
  });
  ctx.fillStyle = "rgba(251,247,255,0.82)";
  ctx.font = "700 12px Inter";
  ctx.textAlign = "center";
  points.forEach((point, index) => {
    ctx.fillText(values[index], point.x, point.y - 12);
    ctx.fillText(labels[index], point.x, height - 8);
  });
}

function drawBar(canvas, values, labels = ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"]) {
  const { ctx, width, height } = setupCanvas(canvas);
  const max = Math.max(...values, 0.25) + 1;
  const gap = 14;
  const barWidth = (width - gap * (values.length + 1)) / values.length;
  ctx.clearRect(0, 0, width, height);
  values.forEach((value, index) => {
    const x = gap + index * (barWidth + gap);
    const barHeight = (value / max) * (height - 34);
    const y = height - barHeight - 10;
    const gradient = ctx.createLinearGradient(0, y, 0, height);
    gradient.addColorStop(0, "#ff4fd8");
    gradient.addColorStop(1, "#8b5cf6");
    ctx.fillStyle = gradient;
    roundRect(ctx, x, y, barWidth, barHeight, 12);
    ctx.fill();
    ctx.fillStyle = "rgba(251,247,255,0.82)";
    ctx.font = "700 12px Inter";
    ctx.textAlign = "center";
    ctx.fillText(`${value}h`, x + barWidth / 2, y - 8);
    ctx.fillText(labels[index], x + barWidth / 2, height - 2);
  });
}

function drawPie(canvas, values, colors) {
  const { ctx, width, height } = setupCanvas(canvas);
  const total = values.reduce((sum, value) => sum + value, 0);
  if (!total) {
    drawEmptyChart(ctx, width, height, "Track habits");
    return;
  }
  let start = -Math.PI / 2;
  const radius = Math.min(width, height) / 2 - 18;
  ctx.clearRect(0, 0, width, height);
  values.forEach((value, index) => {
    const angle = (value / total) * Math.PI * 2;
    ctx.beginPath();
    ctx.moveTo(width / 2, height / 2);
    ctx.fillStyle = colors[index % colors.length] || "#ff4fd8";
    ctx.arc(width / 2, height / 2, radius, start, start + angle);
    ctx.closePath();
    ctx.fill();
    start += angle;
  });
  ctx.fillStyle = "#080917";
  ctx.beginPath();
  ctx.arc(width / 2, height / 2, radius * 0.58, 0, Math.PI * 2);
  ctx.fill();
}

function drawRadar(canvas, values) {
  const { ctx, width, height } = setupCanvas(canvas);
  if (!values.length || values.every((value) => value === 0)) {
    drawEmptyChart(ctx, width, height, "Check skill topics");
    return;
  }
  const center = { x: width / 2, y: height / 2 };
  const radius = Math.min(width, height) / 2 - 24;
  ctx.clearRect(0, 0, width, height);
  ctx.strokeStyle = "rgba(255,255,255,0.1)";
  for (let ring = 1; ring <= 4; ring += 1) {
    polygon(ctx, center, radius * (ring / 4), values.length);
    ctx.stroke();
  }
  ctx.fillStyle = "rgba(255,79,216,0.24)";
  ctx.strokeStyle = "#ff4fd8";
  ctx.lineWidth = 3;
  ctx.beginPath();
  values.forEach((value, index) => {
    const angle = -Math.PI / 2 + (Math.PI * 2 * index) / values.length;
    const r = radius * (value / 100);
    const x = center.x + Math.cos(angle) * r;
    const y = center.y + Math.sin(angle) * r;
    index ? ctx.lineTo(x, y) : ctx.moveTo(x, y);
  });
  ctx.closePath();
  ctx.fill();
  ctx.stroke();
}

function drawEmptyChart(ctx, width, height, label) {
  ctx.clearRect(0, 0, width, height);
  ctx.strokeStyle = "rgba(255,255,255,0.12)";
  ctx.setLineDash([8, 8]);
  ctx.beginPath();
  ctx.arc(width / 2, height / 2, Math.min(width, height) / 3, 0, Math.PI * 2);
  ctx.stroke();
  ctx.setLineDash([]);
  ctx.fillStyle = "rgba(251,247,255,0.76)";
  ctx.font = "700 16px Inter";
  ctx.textAlign = "center";
  ctx.fillText(label, width / 2, height / 2 + 6);
}

function polygon(ctx, center, radius, sides) {
  ctx.beginPath();
  for (let index = 0; index < sides; index += 1) {
    const angle = -Math.PI / 2 + (Math.PI * 2 * index) / sides;
    const x = center.x + Math.cos(angle) * radius;
    const y = center.y + Math.sin(angle) * radius;
    index ? ctx.lineTo(x, y) : ctx.moveTo(x, y);
  }
  ctx.closePath();
}

function roundRect(ctx, x, y, width, height, radius) {
  ctx.beginPath();
  ctx.moveTo(x + radius, y);
  ctx.arcTo(x + width, y, x + width, y + height, radius);
  ctx.arcTo(x + width, y + height, x, y + height, radius);
  ctx.arcTo(x, y + height, x, y, radius);
  ctx.arcTo(x, y, x + width, y, radius);
  ctx.closePath();
}

async function drawCharts() {
  const data = await getAnalytics();
  $$(".aura-chart").forEach((canvas) => {
    const type = canvas.dataset.chart;
    if (type === "line") drawLine(canvas, data.weeklyActivity, data.weekLabels);
    if (type === "bar") drawBar(canvas, data.studyHours, data.weekLabels);
    if (type === "pie") drawPie(canvas, data.habitValues, data.colors);
    if (type === "radar") drawRadar(canvas, data.skillValues.slice(0, 8));
  });
}

if ($(".aura-chart")) {
  drawCharts();
  window.addEventListener("resize", drawCharts);
}
